export default function RetencaoPage() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Retenção</h1>
      <p>Logado ✅</p>
    </main>
  );
}
