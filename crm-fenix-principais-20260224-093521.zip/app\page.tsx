import Image from "next/image";

export default function Home() {
  return (
    <main>
      <h1>Olá, mundo! 🌍</h1>
      <p>Este é meu primeiro projeto Next.js.</p>
    </main>
  );
}
